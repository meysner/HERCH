package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

// ── palette ──────────────────────────────────────────────────────────────────
private val DotBase  = Color(0xFF1A1A1A)   // dim background dot
private val DotGold  = Color(0xFFFFD700)   // letter pixel / bright pulse
private val DotWhite = Color(0xFFEEEEEE)   // occasional white sparkle

// ── grid ─────────────────────────────────────────────────────────────────────
private const val COLS = 31
private const val ROWS = 7
private const val TOTAL = COLS * ROWS

// Each character cell is 5 wide × 7 tall (including 1-col right gap).
// 7 letters × 5 cols = 35 … but we trim the trailing gap → 31 cols fits perfectly.
// Pattern: 1 = lit, 0 = off  (5 cols wide, no trailing gap on last letter)

private val FONT_5x5: Map<Char, List<List<Int>>> = mapOf(
    'H' to listOf(
        listOf(1,0,0,0,1),
        listOf(1,0,0,0,1),
        listOf(1,1,1,1,1),
        listOf(1,0,0,0,1),
        listOf(1,0,0,0,1),
    ),
    'E' to listOf(
        listOf(1,1,1,1,1),
        listOf(1,0,0,0,0),
        listOf(1,1,1,1,0),
        listOf(1,0,0,0,0),
        listOf(1,1,1,1,1),
    ),
    'R' to listOf(
        listOf(1,1,1,1,0),
        listOf(1,0,0,0,1),
        listOf(1,1,1,1,0),
        listOf(1,0,0,1,0),
        listOf(1,0,0,0,1),
    ),
    'M' to listOf(
        listOf(1,0,0,0,1),
        listOf(1,1,0,1,1),
        listOf(1,0,1,0,1),
        listOf(1,0,0,0,1),
        listOf(1,0,0,0,1),
    ),
    'P' to listOf(
        listOf(1,1,1,1,0),
        listOf(1,0,0,0,1),
        listOf(1,1,1,1,0),
        listOf(1,0,0,0,0),
        listOf(1,0,0,0,0),
    ),
    'A' to listOf(
        listOf(0,1,1,1,0),
        listOf(1,0,0,0,1),
        listOf(1,1,1,1,1),
        listOf(1,0,0,0,1),
        listOf(1,0,0,0,1),
    ),
    'C' to listOf(
        listOf(0,1,1,1,0),
        listOf(1,0,0,0,1),
        listOf(1,0,0,0,0),
        listOf(1,0,0,0,1),
        listOf(0,1,1,1,0),
    ),
    'W' to listOf(
        listOf(1,0,0,0,1),
        listOf(1,0,0,0,1),
        listOf(1,0,1,0,1),
        listOf(1,1,0,1,1),
        listOf(1,0,0,0,1),
    ),
)

// Build the 31×5 letter mask (true = this dot is part of a letter)
// Grid is COLS×ROWS; letters sit in the middle vertically (rows 1..5 of 0..6)
private val LETTER_MASK: BooleanArray = run {
    val mask = BooleanArray(TOTAL) { false }
    val word = "HERCH"
    val letterRowOffset = 1  // 1 blank row above, 1 blank row below → 5-row glyphs in 7 rows

    word.forEachIndexed { charIdx, ch ->
        val glyph = FONT_5x5[ch] ?: return@forEachIndexed
        val colOffset = charIdx * 5 + if (charIdx > 0) 0 else 0  // no extra gap, chars are 5-wide
        // Add a 1-dot gap between letters except before first
        val startCol = charIdx * 5 + (charIdx.coerceAtLeast(0))  // 0,5,10,15,20,25,30 → but W is 5 wide = col 30..34 → exceeds COLS
        // Re-derive: letters are 5 wide with 0 inter-gap. 7×5=35 > 31.
        // So use 4-wide chars + 1-wide gap (=5 stride) only up to 6 letters, last has no gap.
        // Stride = 4 col glyph + 1 gap, last letter stride = 4 col glyph only.
        // Re-render with 4-wide reduced glyphs would mangle readability.
        // Instead: use stride=4 for all (letters tightly packed, small gap handled by 1 empty col in each 5-wide glyph end).
        // This is fine since most letters have a 0 rightmost column naturally.
    }

    // Cleaner rebuild: stride = 4 (tight pack), COLS=29 would work; but we keep COLS=31
    // and center 7 letters × 4-stride = 28 cols → 1-col left margin, 2-col right margin.
    // Use 4-col wide glyphs:
    val FONT_4x5: Map<Char, List<List<Int>>> = mapOf(
        'H' to listOf(listOf(1,0,0,1), listOf(1,0,0,1), listOf(1,1,1,1), listOf(1,0,0,1), listOf(1,0,0,1)),
        'E' to listOf(listOf(1,1,1,1), listOf(1,0,0,0), listOf(1,1,1,0), listOf(1,0,0,0), listOf(1,1,1,1)),
        'R' to listOf(listOf(1,1,1,0), listOf(1,0,0,1), listOf(1,1,1,0), listOf(1,0,1,0), listOf(1,0,0,1)),
        'M' to listOf(listOf(1,0,0,1), listOf(1,1,1,1), listOf(1,0,0,1), listOf(1,0,0,1), listOf(1,0,0,1)),
        'P' to listOf(listOf(1,1,1,0), listOf(1,0,0,1), listOf(1,1,1,0), listOf(1,0,0,0), listOf(1,0,0,0)),
        'A' to listOf(listOf(0,1,1,0), listOf(1,0,0,1), listOf(1,1,1,1), listOf(1,0,0,1), listOf(1,0,0,1)),
        'C' to listOf(listOf(0,1,1,0), listOf(1,0,0,1), listOf(1,0,0,0), listOf(1,0,0,1), listOf(0,1,1,0)),
        'W' to listOf(listOf(1,0,0,1), listOf(1,0,0,1), listOf(1,0,1,1), listOf(1,1,1,1), listOf(1,0,0,1)),
    )

    // stride = 4 + 1 gap = 5; 7 letters × 4 + 6 gaps = 28+6 = 34 → too wide for 31.
    // stride = 4 + 0 gap; 7×4 = 28 cols; left margin = (31-28)/2 = 1; right margin = 2.
    word.forEachIndexed { charIdx, ch ->
        val glyph = FONT_4x5[ch] ?: return@forEachIndexed
        val colStart = 1 + charIdx * 4   // 1-dot left margin

        glyph.forEachIndexed { glyphRow, rowBits ->
            val gridRow = letterRowOffset + glyphRow  // rows 1..5
            rowBits.forEachIndexed { glyphCol, bit ->
                if (bit == 1) {
                    val gridCol = colStart + glyphCol
                    if (gridCol < COLS && gridRow < ROWS) {
                        mask[gridRow * COLS + gridCol] = true
                    }
                }
            }
        }
    }
    mask
}

// ── animation constants ───────────────────────────────────────────────────────
private const val BASE_FRAC   = 0.09f   // rest brightness of background dots
private const val LETTER_FRAC = 0.85f   // rest brightness of letter dots (always glowing)
private const val ANIMATORS   = 20      // background sparkle coroutines

/**
 * Dot-matrix logo where "HERCH" is physically *made of dots*.
 *
 * The grid is [COLS]×[ROWS]. Dots belonging to the letterforms hold a steady
 * warm gold glow (LETTER_FRAC) and receive occasional bright pulses.
 * Background dots flicker asynchronously at a low level, giving the panel
 * that Nothing-phone phosphor feel.
 *
 * Usage:
 *   HerchLogo(modifier = Modifier.weight(1f).height(56.dp))
 */
@Composable
fun HerchLogo(modifier: Modifier = Modifier) {

    // One Animatable per dot.
    // Letter dots start at LETTER_FRAC; background dots start at BASE_FRAC.
    val dots = remember {
        Array(TOTAL) { idx ->
            Animatable(if (LETTER_MASK[idx]) LETTER_FRAC else BASE_FRAC)
        }
    }

    LaunchedEffect(Unit) {
        // ── letter pulse coroutines ──────────────────────────────────────────
        // Each letter dot occasionally surges to near-white then settles back.
        repeat(12) { n ->
            launch {
                delay(n * 120L)
                while (true) {
                    delay(Random.nextLong(400L, 2200L))
                    val idx = (0 until TOTAL).filter { LETTER_MASK[it] }.random()

                    dots[idx].animateTo(
                        targetValue   = Random.nextFloat() * 0.15f + 0.85f,
                        animationSpec = tween(
                            durationMillis = Random.nextInt(80, 260),
                            easing         = FastOutSlowInEasing
                        )
                    )
                    dots[idx].animateTo(
                        targetValue   = LETTER_FRAC,
                        animationSpec = tween(
                            durationMillis = Random.nextInt(300, 900),
                            easing         = LinearOutSlowInEasing
                        )
                    )
                }
            }
        }

        // ── background sparkle coroutines ────────────────────────────────────
        repeat(ANIMATORS) { n ->
            launch {
                delay(n * 55L)
                while (true) {
                    delay(Random.nextLong(80L, 700L))
                    val idx = (0 until TOTAL).filter { !LETTER_MASK[it] }.let {
                        if (it.isEmpty()) return@launch
                        it[Random.nextInt(it.size)]
                    }
                    val peak = Random.nextFloat() * 0.45f + 0.18f

                    dots[idx].animateTo(
                        targetValue   = peak,
                        animationSpec = tween(
                            durationMillis = Random.nextInt(100, 400),
                            easing         = FastOutSlowInEasing
                        )
                    )
                    dots[idx].animateTo(
                        targetValue   = BASE_FRAC,
                        animationSpec = tween(
                            durationMillis = Random.nextInt(500, 1400),
                            easing         = LinearOutSlowInEasing
                        )
                    )
                }
            }
        }
    }

    val fractions = dots.map { it.value }

    Canvas(modifier = modifier.fillMaxSize()) {
        val dotRadius = 2.6f.dp.toPx()
        val cellW = size.width  / COLS.toFloat()
        val cellH = size.height / ROWS.toFloat()

        fractions.forEachIndexed { idx, frac ->
            val col = idx % COLS
            val row = idx / COLS
            val isLetter = LETTER_MASK[idx]

            val (base, target, tNorm) = if (isLetter) {
                // Letter dot: lerp between DotBase and DotGold using LETTER_FRAC as floor
                val t = ((frac - LETTER_FRAC) / (1f - LETTER_FRAC)).coerceIn(0f, 1f)
                Triple(DotGold, DotWhite, t)
            } else {
                val t = ((frac - BASE_FRAC) / (1f - BASE_FRAC)).coerceIn(0f, 1f)
                val target = if (idx % 11 == 5) DotWhite else DotGold
                Triple(DotBase, target, t)
            }

            val color  = lerp(base, target, tNorm)
            val radius = dotRadius * if (isLetter) {
                0.85f + 0.30f * tNorm   // letter dots slightly larger
            } else {
                0.65f + 0.50f * tNorm
            }

            drawCircle(
                color  = color,
                radius = radius,
                center = Offset(cellW * col + cellW / 2f, cellH * row + cellH / 2f)
            )
        }
    }
}